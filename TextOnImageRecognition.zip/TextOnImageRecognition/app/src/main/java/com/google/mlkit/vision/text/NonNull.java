package com.google.mlkit.vision.text;

public @interface NonNull {
}
