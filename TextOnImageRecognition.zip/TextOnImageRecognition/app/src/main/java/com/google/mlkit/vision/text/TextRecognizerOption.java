package com.google.mlkit.vision.text;

public class TextRecognizerOption {
    public static Object DEFAULT_OPTIONS;
}
