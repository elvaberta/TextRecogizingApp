package com.google.mlkit.vision.text;

import com.google.mlkit.vision.common.InputImage;

public interface TextRecognizer {
    Object process(InputImage image);
}
