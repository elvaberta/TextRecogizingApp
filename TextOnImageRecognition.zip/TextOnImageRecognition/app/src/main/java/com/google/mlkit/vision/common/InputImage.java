package com.google.mlkit.vision.common;

import android.graphics.Bitmap;

public class InputImage {
    public static InputImage frontBitmap(Bitmap imageBitmap, int i) {
    }
}
