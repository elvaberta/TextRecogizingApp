package com.google.mlkit.vision.text;

public class TextRecognition {

    public static TextRecognizer getClient(Object defaultOptions) {
    }
}
